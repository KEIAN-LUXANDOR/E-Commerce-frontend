
"use client";

import { useEffect, useState, type FormEvent, type ReactNode } from "react";
import {
  Image as ImageIcon,
  RotateCcw,
  SlidersHorizontal,
  Truck,
} from "lucide-react";

import { useListing } from "@/components/catalog/ListingState";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { SpotlightCard } from "@/components/ui/spotlight";
import { buttonVariants } from "@/components/ui/button";
import { countActiveFilters } from "@/lib/catalog/query";
import { cn } from "@/lib/utils";

import type {
  DiamondColor,
  Clarity,
  Cut,
  Finish,
  Fluorescence,
  Lab,
} from "@/lib/types/product";

const CARAT_RANGES = [
  { label: "All carats", min: undefined, max: undefined },
  { label: "1.00+ ct", min: 1, max: undefined },
  { label: "1.50+ ct", min: 1.5, max: undefined },
  { label: "2.00+ ct", min: 2, max: undefined },
  { label: "2.50+ ct", min: 2.5, max: undefined },
];

const COLORS: readonly DiamondColor[] = [
  "D", "E", "F", "G", "H", "I", "J", "K", "L", "M",
];

const CLARITIES: readonly Clarity[] = [
  "FL", "IF", "VVS1", "VVS2", "VS1", "VS2", "SI1", "SI2", "I1", "I2", "I3",
];

const LABS: readonly Lab[] = ["GIA", "IGI", "HRD"];

const CUTS: readonly Cut[] = [
  "IDEAL", "EXCELLENT", "VERY_GOOD", "GOOD", "FAIR",
];

const FINISHES: readonly Finish[] = [
  "EXCELLENT", "VERY_GOOD", "GOOD", "FAIR",
];

const FLUORESCENCE: readonly Fluorescence[] = [
  "NONE", "FAINT", "MEDIUM", "STRONG", "VERY_STRONG",
];

function formatChoice(value: string) {
  return value.replaceAll("_", " ").toLowerCase().replace(/\b\w/g, (letter) => letter.toUpperCase());
}

function FilterChip({
  active,
  children,
  onClick,
  className,
}: {
  active: boolean;
  children: ReactNode;
  onClick: () => void;
  className?: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={cn(
        "inline-flex min-h-9 items-center justify-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-medium transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--brand-accent)] focus-visible:ring-offset-2",
        active
          ? "border-ink bg-ink text-white shadow-sm"
          : "border-line bg-white text-ink-secondary hover:border-brand-accent hover:bg-[var(--brand-accent-muted)] hover:text-ink",
        className,
      )}
    >
      {children}
    </button>
  );
}

function ChoiceGroup<T extends string>({
  label,
  values,
  selected,
  onToggle,
}: {
  label: string;
  values: readonly T[];
  selected: readonly T[];
  onToggle: (value: T) => void;
}) {
  return (
    <div className="min-w-0">
      <p className="mb-2.5 text-[10px] font-semibold uppercase tracking-[0.13em] text-brand-accent">
        {label}
      </p>

      <div className="flex flex-wrap gap-2">
        {values.map((value) => (
          <FilterChip
            key={value}
            active={selected.includes(value)}
            onClick={() => onToggle(value)}
          >
            {formatChoice(value)}
          </FilterChip>
        ))}
      </div>
    </div>
  );
}

function PriceRangeFilter() {
  const { query, update } = useListing();

  const [minimum, setMinimum] = useState(
    query.minPrice !== undefined
      ? String(Math.round(query.minPrice / 100))
      : "",
  );

  const [maximum, setMaximum] = useState(
    query.maxPrice !== undefined
      ? String(Math.round(query.maxPrice / 100))
      : "",
  );

  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setMinimum(
      query.minPrice !== undefined
        ? String(Math.round(query.minPrice / 100))
        : "",
    );
    setMaximum(
      query.maxPrice !== undefined
        ? String(Math.round(query.maxPrice / 100))
        : "",
    );
    setError(null);
  }, [query.minPrice, query.maxPrice]);

  function handleApply(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    const minValue = minimum.trim() === "" ? undefined : Number(minimum);
    const maxValue = maximum.trim() === "" ? undefined : Number(maximum);

    if (
      (minValue !== undefined && (!Number.isFinite(minValue) || minValue < 0)) ||
      (maxValue !== undefined && (!Number.isFinite(maxValue) || maxValue < 0))
    ) {
      setError("Enter valid, non-negative prices.");
      return;
    }

    if (
      minValue !== undefined &&
      maxValue !== undefined &&
      maxValue < minValue
    ) {
      setError("Maximum price must be greater than minimum price.");
      return;
    }

    // ProductQuery stores prices in paise; the inputs display rupees.
    update({
      minPrice: minValue === undefined ? undefined : Math.round(minValue * 100),
      maxPrice: maxValue === undefined ? undefined : Math.round(maxValue * 100),
    });

    setError(null);
  }

  return (
    <form onSubmit={handleApply} className="max-w-lg">
      <p className="mb-2.5 text-[10px] font-semibold uppercase tracking-[0.13em] text-brand-accent">
        Price range (₹)
      </p>

      <div className="flex flex-wrap items-end gap-2">
        <label className="min-w-0 flex-1">
          <span className="mb-1.5 block text-[10px] text-slate">
            Minimum
          </span>
          <input
            type="number"
            min="0"
            step="1"
            inputMode="numeric"
            value={minimum}
            onChange={(event) => {
              setMinimum(event.target.value);
              setError(null);
            }}
            placeholder="No minimum"
            className="h-10 w-full rounded-lg border border-line bg-white px-3 text-sm text-ink outline-none transition-colors placeholder:text-muted focus:border-brand-accent focus:ring-2 focus:ring-[rgba(82,109,137,0.15)]"
          />
        </label>

        <span className="pb-3 text-muted">—</span>

        <label className="min-w-0 flex-1">
          <span className="mb-1.5 block text-[10px] text-slate">
            Maximum
          </span>
          <input
            type="number"
            min="0"
            step="1"
            inputMode="numeric"
            value={maximum}
            onChange={(event) => {
              setMaximum(event.target.value);
              setError(null);
            }}
            placeholder="No maximum"
            className="h-10 w-full rounded-lg border border-line bg-white px-3 text-sm text-ink outline-none transition-colors placeholder:text-muted focus:border-brand-accent focus:ring-2 focus:ring-[rgba(82,109,137,0.15)]"
          />
        </label>

        <button
          type="submit"
          className={cn(
            buttonVariants({ variant: "secondary", size: "sm" }),
            "h-10 shrink-0 rounded-lg border-line-dark px-4",
          )}
        >
          Apply
        </button>
      </div>

      {error && (
        <p role="alert" className="mt-2 text-xs text-out">
          {error}
        </p>
      )}
    </form>
  );
}

export function FilterPanel() {
  const { query, update, clearAll, isPending } = useListing();

  const selectedColors = query.color ?? [];
  const selectedClarities = query.clarity ?? [];
  const selectedLabs = query.lab ?? [];
  const selectedCuts = query.cut ?? [];
  const selectedPolish = query.polish ?? [];
  const selectedSymmetry = query.symmetry ?? [];
  const selectedFluorescence = query.fluorescence ?? [];

  const activeCount = countActiveFilters(query);

  function toggleValue<T extends string>(
    current: readonly T[],
    value: T,
  ): T[] | undefined {
    const next = current.includes(value)
      ? current.filter((item) => item !== value)
      : [...current, value];

    return next.length ? next : undefined;
  }

  return (
    <SpotlightCard
      spotlightColor="rgba(82, 109, 137, 0.075)"
      className="rounded-[1.4rem] border-line bg-white p-0 shadow-sm"
    >
      <div className="relative z-10">
        {/* Panel heading */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-line px-5 py-4 sm:px-6">
          <div className="flex items-center gap-3">
            <div className="grid size-9 place-items-center rounded-xl border border-line bg-[var(--brand-accent-muted)] text-brand-accent">
              <SlidersHorizontal className="size-4" aria-hidden="true" />
            </div>

            <div>
              <h2 className="font-serif text-lg font-medium text-ink">
                Refine your selection
              </h2>
              <p className="mt-0.5 text-[10px] text-slate">
                Choose the characteristics that matter to you.
              </p>
            </div>

            {activeCount > 0 && (
              <span className="inline-flex min-w-6 items-center justify-center rounded-full bg-ink px-2 py-1 text-[10px] font-semibold tabular-nums text-white">
                {activeCount}
              </span>
            )}
          </div>

          <div className="flex items-center gap-3">
            {isPending && (
              <span role="status" className="text-[10px] text-brand-accent">
                Updating…
              </span>
            )}

            {activeCount > 0 && (
              <button
                type="button"
                onClick={clearAll}
                className="inline-flex min-h-9 items-center gap-1.5 rounded-full px-3 text-[11px] font-medium text-brand-accent transition-colors hover:bg-[var(--brand-accent-muted)] hover:text-ink focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--brand-accent)]"
              >
                <RotateCcw className="size-3.5" aria-hidden="true" />
                Reset filters
              </button>
            )}
          </div>
        </div>

        {/* Primary filter accordions */}
        <Accordion
          type="multiple"
          defaultValue={["carat"]}
          className="grid min-w-0 gap-x-6 px-5 sm:px-6 md:grid-cols-2 xl:grid-cols-4"
        >
          <AccordionItem value="carat" className="min-w-0 border-line">
            <AccordionTrigger className="py-4 text-[11px] font-semibold uppercase tracking-[0.12em] text-ink focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--brand-accent)]">
              Carat weight
            </AccordionTrigger>

            <AccordionContent>
              <div className="flex flex-wrap gap-2">
                {CARAT_RANGES.map((range) => {
                  const active =
                    query.minCarat === range.min &&
                    query.maxCarat === range.max;

                  return (
                    <FilterChip
                      key={range.label}
                      active={active}
                      onClick={() =>
                        update({
                          minCarat: range.min,
                          maxCarat: range.max,
                        })
                      }
                    >
                      {range.label}
                    </FilterChip>
                  );
                })}
              </div>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="colour" className="min-w-0 border-line">
            <AccordionTrigger className="py-4 text-[11px] font-semibold uppercase tracking-[0.12em] text-ink focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--brand-accent)]">
              Colour grade
            </AccordionTrigger>

            <AccordionContent>
              <div className="flex flex-wrap gap-2">
                {COLORS.map((color) => (
                  <FilterChip
                    key={color}
                    active={selectedColors.includes(color)}
                    onClick={() =>
                      update({
                        color: toggleValue(selectedColors, color),
                      })
                    }
                    className="min-w-9 px-2"
                  >
                    {color}
                  </FilterChip>
                ))}
              </div>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="clarity" className="min-w-0 border-line">
            <AccordionTrigger className="py-4 text-[11px] font-semibold uppercase tracking-[0.12em] text-ink focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--brand-accent)]">
              Clarity grade
            </AccordionTrigger>

            <AccordionContent>
              <div className="flex flex-wrap gap-2">
                {CLARITIES.map((clarity) => (
                  <FilterChip
                    key={clarity}
                    active={selectedClarities.includes(clarity)}
                    onClick={() =>
                      update({
                        clarity: toggleValue(selectedClarities, clarity),
                      })
                    }
                  >
                    {clarity}
                  </FilterChip>
                ))}
              </div>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="price" className="min-w-0 border-line">
            <AccordionTrigger className="py-4 text-[11px] font-semibold uppercase tracking-[0.12em] text-ink focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--brand-accent)]">
              Price
            </AccordionTrigger>

            <AccordionContent>
              <PriceRangeFilter />
            </AccordionContent>
          </AccordionItem>

          <AccordionItem
            value="advanced"
            className="min-w-0 border-line md:col-span-2 xl:col-span-4"
          >
            <AccordionTrigger className="py-4 text-[11px] font-semibold uppercase tracking-[0.12em] text-brand-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--brand-accent)]">
              More filters
            </AccordionTrigger>

            <AccordionContent>
              <div className="grid gap-6 sm:grid-cols-2 xl:grid-cols-3">
                <ChoiceGroup
                  label="Certification laboratory"
                  values={LABS}
                  selected={selectedLabs}
                  onToggle={(value) =>
                    update({ lab: toggleValue(selectedLabs, value) })
                  }
                />

                <ChoiceGroup
                  label="Cut grade"
                  values={CUTS}
                  selected={selectedCuts}
                  onToggle={(value) =>
                    update({ cut: toggleValue(selectedCuts, value) })
                  }
                />

                <ChoiceGroup
                  label="Polish"
                  values={FINISHES}
                  selected={selectedPolish}
                  onToggle={(value) =>
                    update({ polish: toggleValue(selectedPolish, value) })
                  }
                />

                <ChoiceGroup
                  label="Symmetry"
                  values={FINISHES}
                  selected={selectedSymmetry}
                  onToggle={(value) =>
                    update({ symmetry: toggleValue(selectedSymmetry, value) })
                  }
                />

                <ChoiceGroup
                  label="Fluorescence"
                  values={FLUORESCENCE}
                  selected={selectedFluorescence}
                  onToggle={(value) =>
                    update({
                      fluorescence: toggleValue(selectedFluorescence, value),
                    })
                  }
                />

                <div className="min-w-0">
                  <p className="mb-2.5 text-[10px] font-semibold uppercase tracking-[0.13em] text-brand-accent">
                    Availability &amp; images
                  </p>

                  <div className="flex flex-wrap gap-2">
                    <FilterChip
                      active={query.quickShip === true}
                      onClick={() =>
                        update({
                          quickShip: query.quickShip ? undefined : true,
                        })
                      }
                    >
                      <Truck className="size-3.5" aria-hidden="true" />
                      Quick ship
                    </FilterChip>

                    <FilterChip
                      active={query.withImage === true}
                      onClick={() =>
                        update({
                          withImage: query.withImage ? undefined : true,
                        })
                      }
                    >
                      <ImageIcon className="size-3.5" aria-hidden="true" />
                      With images
                    </FilterChip>
                  </div>
                </div>
              </div>
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      </div>
    </SpotlightCard>
  );
}

export default FilterPanel;
